# ACE AI — Android 1.1

This project wraps the ACE mobile web app in a native Android shell.

## Included
- ACE AI launcher/app identity
- Branded native splash screen
- Offline/error screen with Retry
- Native Android microphone permission handling
- Floating voice-input button using Android SpeechRecognizer
- Voice results inserted into the ACE chat composer
- WebView JavaScript + DOM storage + cookies enabled
- Android back navigation
- External links opened outside the ACE WebView
- Portrait-first phone experience

## Build
Open this folder in Android Studio and let Gradle sync. Then use:

**Build → Build APK(s)**

Debug APK output:
`app/build/outputs/apk/debug/app-debug.apk`

If using a terminal with Gradle installed:

```bash
gradle assembleDebug
```

This source package does not include a Gradle wrapper, so Android Studio is the easiest build route.

## Voice input
The first time the user taps the ACE microphone button, Android asks for microphone permission. Speech is recognized locally/by the device speech service and the result is inserted into the currently available ACE composer.

If the ACE website itself requests microphone access, the WebView permission request is also handled by the Android shell.

## Network/offline behavior
ACE currently loads:
`https://create-ace-ai-agent.v0.build/`

The app needs an internet connection for the hosted ACE web experience. If the main page cannot load, the app shows an ACE-branded offline screen with Retry.

## Important
The Android shell does not contain an AI API key. Keep API credentials on a secure backend/server rather than embedding secret keys in the APK.
