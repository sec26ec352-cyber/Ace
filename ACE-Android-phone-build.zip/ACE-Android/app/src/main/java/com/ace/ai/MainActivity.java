package com.ace.ai;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String ACE_URL = "https://create-ace-ai-agent.v0.build/";
    private static final int MIC_PERMISSION = 401;

    private FrameLayout root;
    private WebView webView;
    private View splashView;
    private View offlineView;
    private ImageView micButton;
    private SpeechRecognizer speechRecognizer;
    private boolean listening = false;
    private boolean pageLoaded = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(2, 6, 23));
        getWindow().setNavigationBarColor(Color.rgb(2, 6, 23));
        getWindow().getDecorView().setSystemUiVisibility(0);

        buildRoot();
        showSplash();
        setupWebView();
        setupOfflineView();
        setupVoiceButton();
        setupSpeechRecognizer();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isOnline()) loadAce(); else showOffline();
        }, 650);
    }

    private void buildRoot() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 6, 23));
        setContentView(root);
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(28), dp(28), dp(28), dp(28));
        splash.setBackgroundResource(com.ace.ai.R.drawable.ace_splash_gradient);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.ace.ai.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        splash.addView(logo, new LinearLayout.LayoutParams(dp(112), dp(112)));

        TextView title = new TextView(this);
        title.setText("ACE AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(18);
        splash.addView(title, titleLp);

        TextView subtitle = new TextView(this);
        subtitle.setText("Your personal AI agent");
        subtitle.setTextColor(Color.rgb(148, 163, 184));
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(6);
        splash.addView(subtitle, subLp);

        ProgressBar progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        progressLp.topMargin = dp(28);
        splash.addView(progress, progressLp);

        splashView = splash;
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                            } else {
                                request.deny();
                                requestMicPermission();
                            }
                            return;
                        }
                    }
                    request.deny();
                });
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("create-ace-ai-agent.v0.build") || host.endsWith(".v0.build"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                pageLoaded = false;
                super.onPageStarted(view, url, favicon);
            }

            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                hideSplash();
                hideOffline();
                super.onPageFinished(view, url);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showOffline();
                super.onReceivedError(view, request, error);
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
    }


    private void setupOfflineView() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(28), dp(28), dp(28), dp(28));
        card.setBackgroundResource(R.drawable.ace_splash_gradient);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        card.addView(icon, new LinearLayout.LayoutParams(dp(84), dp(84)));

        TextView title = new TextView(this);
        title.setText(R.string.offline_title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(18);
        card.addView(title, titleLp);

        TextView message = new TextView(this);
        message.setText(R.string.offline_message);
        message.setTextColor(Color.rgb(148, 163, 184));
        message.setTextSize(15);
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams msgLp = new LinearLayout.LayoutParams(-1, -2);
        msgLp.topMargin = dp(8);
        card.addView(message, msgLp);

        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setTextColor(Color.WHITE);
        retry.setAllCaps(false);
        retry.setBackgroundResource(R.drawable.ace_mic_bg);
        retry.setOnClickListener(v -> { if (isOnline()) loadAce(); else Toast.makeText(this, R.string.offline_message, Toast.LENGTH_SHORT).show(); });
        LinearLayout.LayoutParams retryLp = new LinearLayout.LayoutParams(dp(150), dp(52));
        retryLp.gravity = Gravity.CENTER_HORIZONTAL;
        retryLp.topMargin = dp(22);
        card.addView(retry, retryLp);

        offlineView = card;
        root.addView(offlineView, new FrameLayout.LayoutParams(-1, -1));
        offlineView.setVisibility(View.GONE);
    }

    private void setupVoiceButton() {
        micButton = new ImageView(this);
        micButton.setImageResource(android.R.drawable.ic_btn_speak_now);
        micButton.setColorFilter(Color.WHITE);
        micButton.setBackgroundResource(R.drawable.ace_mic_bg);
        micButton.setPadding(dp(15), dp(15), dp(15), dp(15));
        micButton.setContentDescription("Voice input");
        micButton.setElevation(dp(8));
        micButton.setOnClickListener(v -> toggleListening());

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.END | Gravity.BOTTOM);
        lp.rightMargin = dp(16);
        lp.bottomMargin = dp(84);
        root.addView(micButton, lp);
    }

    private void setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            micButton.setVisibility(View.GONE);
            return;
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { setListening(true); }
            @Override public void onBeginningOfSpeech() { setListening(true); }
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { setListening(false); }
            @Override public void onError(int error) {
                setListening(false);
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    Toast.makeText(MainActivity.this, "Voice input unavailable. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) insertVoiceText(matches.get(0));
                setListening(false);
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void toggleListening() {
        if (listening) {
            if (speechRecognizer != null) speechRecognizer.stopListening();
            setListening(false);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission();
            return;
        }
        if (speechRecognizer == null) {
            Toast.makeText(this, "Voice input is not available on this device.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        speechRecognizer.startListening(intent);
    }

    private void requestMicPermission() {
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone enabled. Tap the ACE mic again.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == MIC_PERMISSION) {
            Toast.makeText(this, "Microphone permission is required for voice input.", Toast.LENGTH_SHORT).show();
        }
    }

    private void insertVoiceText(String text) {
        if (webView == null || text == null || text.trim().isEmpty()) return;
        String js = "(function(){var t=" + org.json.JSONObject.quote(text) + ";" +
                "var e=document.activeElement||document.querySelector('textarea,input,[contenteditable=\\\"true\\\"]');" +
                "if(!e)e=document.querySelector('textarea,input,[contenteditable=\\\"true\\\"]');" +
                "if(!e)return false;" +
                "if(e.isContentEditable){e.innerText=t;}else{var s=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),'value');if(s&&s.set)s.set.call(e,t);else e.value=t;}" +
                "e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.focus();return true;})()";
        webView.evaluateJavascript(js, value -> {
            if ("false".equals(value)) Toast.makeText(this, "Tap the message box first, then use voice input.", Toast.LENGTH_SHORT).show();
        });
    }

    private void setListening(boolean value) {
        listening = value;
        if (micButton == null) return;
        micButton.setBackgroundResource(value ? R.drawable.ace_mic_bg_listening : R.drawable.ace_mic_bg);
        micButton.setContentDescription(value ? "Stop voice input" : "Voice input");
    }

    private void loadAce() {
        hideOffline();
        webView.loadUrl(ACE_URL);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }

    private void showOffline() {
        hideSplash();
        if (offlineView != null) offlineView.setVisibility(View.VISIBLE);
        if (micButton != null) micButton.setVisibility(View.GONE);
    }

    private void hideOffline() {
        if (offlineView != null) offlineView.setVisibility(View.GONE);
        if (micButton != null) micButton.setVisibility(View.VISIBLE);
    }

    private void hideSplash() {
        if (splashView != null) splashView.setVisibility(View.GONE);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
