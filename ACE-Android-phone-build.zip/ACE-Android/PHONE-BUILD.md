# ACE Android — phone-only APK build

You can build the APK using GitHub Actions from an Android phone; Android Studio is not required.

1. Create a GitHub repository.
2. Upload the contents of this project to the repository.
3. Open the **Actions** tab.
4. Select **Build ACE APK** and run the workflow.
5. When it finishes, open the workflow run and download the **ACE-debug-apk** artifact.
6. Extract `app-debug.apk` on your phone and install it.

Note: Android may ask you to allow your browser/files app to install unknown apps.
